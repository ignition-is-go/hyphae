use std::{
    env,
    hint::black_box,
    sync::{
        Arc,
        atomic::{AtomicI64, AtomicU64, Ordering},
    },
    thread,
    time::Instant,
};

use hyphae::{
    Cell, CellMutable, Gettable, MapExt, Materialize, Mutable, Signal, Watchable, batch,
    join_vec, scheduler::no_coalesce,
};

const PRODUCERS: usize = 8;
const DEFAULT_OPS: u64 = 20_000;

fn main() -> Result<(), String> {
    let ops = env::args().nth(1).map_or(Ok(DEFAULT_OPS), |raw| {
        raw.parse::<u64>().map_err(|error| error.to_string())
    })?;
    let (sources, sink): (Vec<Cell<i64, CellMutable>>, _) = no_coalesce(|| {
        let sources: Vec<Cell<i64, CellMutable>> =
            (0..PRODUCERS).map(|_| Cell::new(0_i64)).collect();
        let sink = join_vec(sources.iter().cloned().map(Cell::lock).collect())
            .materialize()
            .map(|values: &Vec<i64>| values.iter().sum::<i64>())
            .materialize();
        (sources, sink)
    });

    let delivered = Arc::new(AtomicU64::new(0));
    let previous = Arc::new(AtomicI64::new(-1));
    let order_failures = Arc::new(AtomicU64::new(0));
    let guard = {
        let delivered = Arc::clone(&delivered);
        let previous = Arc::clone(&previous);
        let order_failures = Arc::clone(&order_failures);
        sink.subscribe(move |signal| {
            if let Signal::Value(value) = signal {
                let old = previous.swap(**value, Ordering::Relaxed);
                if **value != old.saturating_add(1) {
                    order_failures.fetch_add(1, Ordering::Relaxed);
                }
                delivered.fetch_add(1, Ordering::Relaxed);
            }
        })
    };
    delivered.store(0, Ordering::Relaxed);
    order_failures.store(0, Ordering::Relaxed);

    let started = Instant::now();
    thread::scope(|scope| {
        for (index, source) in sources.iter().enumerate() {
            scope.spawn(move || {
                for i in 0..ops {
                    let value = i64::try_from(i.saturating_add(1)).unwrap_or(i64::MAX);
                    batch(|| source.set(black_box(value)));
                }
                black_box(index);
            });
        }
    });
    let elapsed = started.elapsed();

    let expected_root = i64::try_from(ops).unwrap_or(i64::MAX);
    let producer_count = i64::try_from(PRODUCERS).unwrap_or(i64::MAX);
    let expected_sum = expected_root.saturating_mul(producer_count);
    let expected_deliveries = ops.saturating_mul(u64::try_from(PRODUCERS).unwrap_or(u64::MAX));
    for source in &sources {
        assert_eq!(source.get(), expected_root);
    }
    assert_eq!(sink.get(), expected_sum);
    assert_eq!(delivered.load(Ordering::Relaxed), expected_deliveries);
    assert_eq!(order_failures.load(Ordering::Relaxed), 0);
    black_box(&guard);

    println!(
        "{{\"producers\":{PRODUCERS},\"ops_per_thread\":{ops},\"elapsed_ns\":{},\"delivered\":{},\"order_failures\":{},\"final_sum\":{}}}",
        elapsed.as_nanos(),
        delivered.load(Ordering::Relaxed),
        order_failures.load(Ordering::Relaxed),
        sink.get()
    );
    Ok(())
}
