use std::{
    env,
    hint::black_box,
    sync::{Arc, atomic::{AtomicU64, Ordering}},
    thread,
    time::Instant,
};
use hyphae::{Cell, CellMutable, Gettable, MapExt, Materialize, Mutable, Signal, Watchable, batch};

const THREADS: usize = 2;
const DEFAULT_OPS: u64 = 20_000;

fn main() -> Result<(), String> {
    let ops = env::args().nth(1).map_or(Ok(DEFAULT_OPS), |raw| raw.parse::<u64>().map_err(|e| e.to_string()))?;
    let sources: Vec<Cell<i64, CellMutable>> = (0..THREADS).map(|_| Cell::new(0_i64)).collect();
    let delivered: Vec<Arc<AtomicU64>> = (0..THREADS).map(|_| Arc::new(AtomicU64::new(0))).collect();
    let derived: Vec<_> = sources.iter().map(|source| source.clone().map(|v| v.saturating_add(1)).materialize()).collect();
    let guards: Vec<_> = derived.iter().zip(&delivered).map(|(cell, count)| {
        let count = Arc::clone(count);
        cell.subscribe(move |signal| { if let Signal::Value(_) = signal { count.fetch_add(1, Ordering::Relaxed); } })
    }).collect();
    for count in &delivered { count.store(0, Ordering::Relaxed); }
    let started = Instant::now();
    thread::scope(|scope| {
        for (index, source) in sources.iter().enumerate() {
            scope.spawn(move || {
                for i in 0..ops {
                    let value = i64::try_from(i).unwrap_or(i64::MAX);
                    batch(|| source.set(black_box(value)));
                }
                black_box(index);
            });
        }
    });
    let elapsed = started.elapsed();
    let final_expected = i64::try_from(ops.saturating_sub(1)).unwrap_or(i64::MAX);
    let counts: Vec<u64> = delivered.iter().map(|v| v.load(Ordering::Relaxed)).collect();
    for source in &sources { assert_eq!(source.get(), final_expected); }
    for cell in &derived { assert_eq!(cell.get(), final_expected.saturating_add(1)); }
    assert_eq!(counts.len(), THREADS);
    black_box(&guards);
    println!("{{\"ops_per_thread\":{ops},\"elapsed_ns\":{},\"delivered\":[{},{}],\"total_delivered\":{}}}", elapsed.as_nanos(), counts.first().copied().unwrap_or(0), counts.get(1).copied().unwrap_or(0), counts.iter().sum::<u64>());
    Ok(())
}
