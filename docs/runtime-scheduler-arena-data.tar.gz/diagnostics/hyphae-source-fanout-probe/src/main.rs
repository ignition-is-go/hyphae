use std::{
    env,
    hint::black_box,
    sync::{
        Arc,
        atomic::{AtomicU64, Ordering},
    },
    time::Instant,
};

use hyphae::{Signal, Source};

const DEFAULT_FANOUT: usize = 128;
const DEFAULT_WARMUP: u64 = 10_000;
const DEFAULT_EMITS: u64 = 1_000_000;
const PAYLOAD: u64 = 7;

fn parse_arg(index: usize, default: u64) -> Result<u64, String> {
    let Some(raw) = env::args().nth(index) else {
        return Ok(default);
    };
    raw.parse::<u64>()
        .map_err(|error| format!("invalid argument {index} ({raw:?}): {error}"))
}

fn main() -> Result<(), String> {
    let fanout_u64 = parse_arg(1, u64::try_from(DEFAULT_FANOUT).map_err(|error| error.to_string())?)?;
    let fanout = usize::try_from(fanout_u64).map_err(|error| error.to_string())?;
    let warmup = parse_arg(2, DEFAULT_WARMUP)?;
    let emits = parse_arg(3, DEFAULT_EMITS)?;

    let source = Source::<u64>::new();
    let hits = Arc::new(AtomicU64::new(0));
    let mismatches = Arc::new(AtomicU64::new(0));
    let guards = (0..fanout)
        .map(|_| {
            let hits = Arc::clone(&hits);
            let mismatches = Arc::clone(&mismatches);
            source.subscribe(move |signal| {
                if let Signal::Value(value) = signal {
                    hits.fetch_add(1, Ordering::Relaxed);
                    if **value != PAYLOAD {
                        mismatches.fetch_add(1, Ordering::Relaxed);
                    }
                }
            })
        })
        .collect::<Vec<_>>();

    for _ in 0..warmup {
        source.emit(black_box(PAYLOAD));
    }
    hits.store(0, Ordering::Relaxed);
    mismatches.store(0, Ordering::Relaxed);

    let started = Instant::now();
    for _ in 0..emits {
        source.emit(black_box(PAYLOAD));
    }
    let elapsed = started.elapsed();

    let expected = emits
        .checked_mul(fanout_u64)
        .ok_or_else(|| "expected hit count overflowed".to_owned())?;
    assert_eq!(hits.load(Ordering::Relaxed), expected);
    assert_eq!(mismatches.load(Ordering::Relaxed), 0);
    black_box(&guards);

    println!(
        "{{\"fanout\":{fanout},\"warmup\":{warmup},\"emits\":{emits},\"hits\":{expected},\"elapsed_ns\":{}}}",
        elapsed.as_nanos()
    );
    Ok(())
}
