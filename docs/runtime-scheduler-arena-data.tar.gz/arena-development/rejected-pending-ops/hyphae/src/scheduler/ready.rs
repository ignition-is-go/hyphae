use std::collections::BTreeMap;

use rustc_hash::FxHashMap;
use uuid::Uuid;

pub(super) type PendingRun = Box<dyn FnOnce() + Send>;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct OpHandle {
    index: usize,
    generation: u64,
}

struct OpSlot {
    generation: u64,
    run: Option<PendingRun>,
}

#[derive(Default)]
struct PendingOps {
    slots: Vec<OpSlot>,
    free: Vec<usize>,
}

impl PendingOps {
    fn insert(&mut self, run: PendingRun) -> OpHandle {
        if let Some(index) = self.free.pop()
            && let Some(slot) = self.slots.get_mut(index)
        {
            slot.run = Some(run);
            return OpHandle {
                index,
                generation: slot.generation,
            };
        }

        let index = self.slots.len();
        self.slots.push(OpSlot {
            generation: 1,
            run: Some(run),
        });
        OpHandle {
            index,
            generation: 1,
        }
    }

    fn take(&mut self, handle: OpHandle) -> Option<PendingRun> {
        let slot = self.slots.get_mut(handle.index)?;
        if slot.generation != handle.generation {
            return None;
        }
        let run = slot.run.take()?;
        if let Some(next) = slot.generation.checked_add(1) {
            slot.generation = next;
            self.free.push(handle.index);
        }
        Some(run)
    }

    fn replace(&mut self, handle: OpHandle, run: PendingRun) -> Result<PendingRun, PendingRun> {
        let Some(slot) = self.slots.get_mut(handle.index) else {
            return Err(run);
        };
        if slot.generation != handle.generation {
            return Err(run);
        }
        if let Some(displaced) = slot.run.take() {
            slot.run = Some(run);
            Ok(displaced)
        } else {
            Err(run)
        }
    }

    fn is_live(&self, handle: OpHandle) -> bool {
        self.slots
            .get(handle.index)
            .is_some_and(|slot| slot.generation == handle.generation && slot.run.is_some())
    }
}

#[derive(Default)]
struct Group {
    first: Option<OpHandle>,
    rest: Vec<OpHandle>,
    live: usize,
}

impl Group {
    fn push(&mut self, handle: OpHandle) {
        if self.first.is_none() {
            self.first = Some(handle);
        } else {
            self.rest.push(handle);
        }
    }

    fn handle_count(&self) -> usize {
        usize::from(self.first.is_some()).saturating_add(self.rest.len())
    }

    fn compact(&mut self, ops: &PendingOps) {
        if self.first.is_some_and(|handle| !ops.is_live(handle)) {
            self.first = None;
        }
        self.rest.retain(|&handle| ops.is_live(handle));
        if self.first.is_none() && !self.rest.is_empty() {
            self.first = Some(self.rest.remove(0));
        }
    }

    fn into_handles(self) -> impl Iterator<Item = OpHandle> {
        self.first.into_iter().chain(self.rest)
    }
}

/// Dense pending-operation storage plus one ordered frontier entry per
/// `(height, cell)`. Superseded operations leave generation-checked tombstones
/// in their former group, so replacement is O(1) in the dense arena and a later
/// terminal/event retains its arrival position.
pub(super) struct ReadyQueue {
    ops: PendingOps,
    frontier: BTreeMap<(u64, Uuid), Group>,
    scheduled: FxHashMap<Uuid, (u64, OpHandle, bool)>,
}

impl ReadyQueue {
    pub(super) fn new() -> Self {
        Self {
            ops: PendingOps::default(),
            frontier: BTreeMap::new(),
            scheduled: FxHashMap::default(),
        }
    }

    /// Queue one operation and return a superseded closure for destruction
    /// after the caller releases the scheduler mutex.
    pub(super) fn enqueue(
        &mut self,
        id: Uuid,
        height: u64,
        coalesce: bool,
        run: PendingRun,
    ) -> Option<PendingRun> {
        let run = if coalesce
            && let Some(&(old_height, handle, true)) = self.scheduled.get(&id)
            && old_height == height
        {
            match self.ops.replace(handle, run) {
                Ok(displaced) => return Some(displaced),
                Err(run) => run,
            }
        } else {
            run
        };

        let displaced = if coalesce {
            self.remove_scheduled(id)
        } else {
            if let Some((scheduled_height, _, is_tail)) = self.scheduled.get_mut(&id)
                && *scheduled_height == height
            {
                *is_tail = false;
            }
            None
        };

        let handle = self.ops.insert(run);
        let group = self.frontier.entry((height, id)).or_default();
        group.push(handle);
        group.live = group.live.saturating_add(1);
        if coalesce {
            self.scheduled.insert(id, (height, handle, true));
        }
        displaced
    }

    fn remove_scheduled(&mut self, id: Uuid) -> Option<PendingRun> {
        let (height, handle, _) = self.scheduled.remove(&id)?;
        let displaced = self.ops.take(handle)?;
        let key = (height, id);
        let remove_group = if let Some(group) = self.frontier.get_mut(&key) {
            group.live = group.live.saturating_sub(1);
            let compact_at = group.live.saturating_mul(2).saturating_add(8);
            if group.handle_count() > compact_at {
                group.compact(&self.ops);
            }
            group.live == 0
        } else {
            false
        };
        if remove_group {
            self.frontier.remove(&key);
        }
        Some(displaced)
    }

    pub(super) fn pop_min_height_groups(&mut self) -> Option<Vec<Vec<PendingRun>>> {
        let target = self
            .frontier
            .first_key_value()
            .map(|(&(height, _), _)| height)?;
        let mut groups = Vec::new();

        while self
            .frontier
            .first_key_value()
            .is_some_and(|(&(height, _), _)| height == target)
        {
            let Some(((_, id), group)) = self.frontier.pop_first() else {
                break;
            };
            let mut runs = Vec::with_capacity(group.live);
            for handle in group.into_handles() {
                if let Some(run) = self.ops.take(handle) {
                    if self
                        .scheduled
                        .get(&id)
                        .is_some_and(|&(_, scheduled, _)| scheduled == handle)
                    {
                        self.scheduled.remove(&id);
                    }
                    runs.push(run);
                }
            }
            if !runs.is_empty() {
                groups.push(runs);
            }
        }

        (!groups.is_empty()).then_some(groups)
    }

    pub(super) fn is_empty(&self) -> bool {
        self.frontier.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use std::{
        collections::BTreeMap,
        sync::{Arc, Mutex},
    };

    use super::*;

    fn recorded(value: u8, seen: &Arc<Mutex<Vec<u8>>>) -> PendingRun {
        let seen = Arc::clone(seen);
        Box::new(move || {
            if let Ok(mut seen) = seen.lock() {
                seen.push(value);
            }
        })
    }

    fn run(groups: Vec<Vec<PendingRun>>) {
        for group in groups {
            for op in group {
                op();
            }
        }
    }

    fn snapshot(seen: &Arc<Mutex<Vec<u8>>>) -> Vec<u8> {
        match seen.lock() {
            Ok(seen) => seen.clone(),
            Err(poisoned) => poisoned.into_inner().clone(),
        }
    }

    struct ReferenceQueue {
        order: BTreeMap<(u64, Uuid, u64), u16>,
        scheduled: FxHashMap<Uuid, (u64, u64)>,
        sequence: u64,
    }

    impl ReferenceQueue {
        fn new() -> Self {
            Self {
                order: BTreeMap::new(),
                scheduled: FxHashMap::default(),
                sequence: 0,
            }
        }

        fn enqueue(&mut self, id: Uuid, height: u64, coalesce: bool, payload: u16) {
            let sequence = self.sequence;
            self.sequence = self.sequence.saturating_add(1);
            if coalesce
                && let Some((old_height, old_sequence)) =
                    self.scheduled.insert(id, (height, sequence))
            {
                self.order.remove(&(old_height, id, old_sequence));
            }
            self.order.insert((height, id, sequence), payload);
        }

        fn pop(&mut self) -> Option<Vec<u16>> {
            let target = self
                .order
                .first_key_value()
                .map(|(&(height, _, _), _)| height)?;
            let mut payloads = Vec::new();
            while self
                .order
                .first_key_value()
                .is_some_and(|(&(height, _, _), _)| height == target)
            {
                let Some(((_, id, sequence), payload)) = self.order.pop_first() else {
                    break;
                };
                if self
                    .scheduled
                    .get(&id)
                    .is_some_and(|&(_, live_sequence)| live_sequence == sequence)
                {
                    self.scheduled.remove(&id);
                }
                payloads.push(payload);
            }
            Some(payloads)
        }
    }

    fn recorded_u16(value: u16, seen: &Arc<Mutex<Vec<u16>>>) -> PendingRun {
        let seen = Arc::clone(seen);
        Box::new(move || {
            if let Ok(mut seen) = seen.lock() {
                seen.push(value);
            }
        })
    }

    fn drain_u16(seen: &Arc<Mutex<Vec<u16>>>) -> Vec<u16> {
        match seen.lock() {
            Ok(mut seen) => std::mem::take(&mut *seen),
            Err(poisoned) => std::mem::take(&mut *poisoned.into_inner()),
        }
    }

    #[test]
    fn coalescing_replaces_the_old_operation() {
        let id = Uuid::new_v4();
        let seen = Arc::new(Mutex::new(Vec::new()));
        let mut queue = ReadyQueue::new();
        assert!(queue.enqueue(id, 2, true, recorded(1, &seen)).is_none());
        let displaced = queue.enqueue(id, 2, true, recorded(2, &seen));
        drop(displaced);
        assert_eq!(queue.ops.slots.len(), 1);
        assert_eq!(queue.frontier.len(), 1);
        let groups = queue.pop_min_height_groups();
        assert!(groups.is_some(), "coalesced group was missing");
        let Some(groups) = groups else {
            return;
        };
        run(groups);
        assert_eq!(snapshot(&seen), vec![2]);
        assert!(queue.is_empty());
    }

    #[test]
    fn terminal_between_values_keeps_arrival_order() {
        let id = Uuid::new_v4();
        let seen = Arc::new(Mutex::new(Vec::new()));
        let mut queue = ReadyQueue::new();
        assert!(queue.enqueue(id, 1, true, recorded(1, &seen)).is_none());
        assert!(queue.enqueue(id, 1, false, recorded(2, &seen)).is_none());
        let displaced = queue.enqueue(id, 1, true, recorded(3, &seen));
        drop(displaced);
        let groups = queue.pop_min_height_groups();
        assert!(groups.is_some(), "mixed group was missing");
        let Some(groups) = groups else {
            return;
        };
        run(groups);
        assert_eq!(snapshot(&seen), vec![2, 3]);
    }

    #[test]
    fn height_change_removes_an_empty_old_group() {
        let id = Uuid::new_v4();
        let seen = Arc::new(Mutex::new(Vec::new()));
        let mut queue = ReadyQueue::new();
        assert!(queue.enqueue(id, 8, true, recorded(8, &seen)).is_none());
        let displaced = queue.enqueue(id, 3, true, recorded(3, &seen));
        drop(displaced);
        let groups = queue.pop_min_height_groups();
        assert!(groups.is_some(), "replacement group was missing");
        let Some(groups) = groups else {
            return;
        };
        run(groups);
        assert_eq!(snapshot(&seen), vec![3]);
        assert!(queue.is_empty());
    }

    #[test]
    fn noncoalescing_events_share_one_ordered_group() {
        let id = Uuid::new_v4();
        let seen = Arc::new(Mutex::new(Vec::new()));
        let mut queue = ReadyQueue::new();
        for value in 0..16 {
            assert!(
                queue
                    .enqueue(id, 4, false, recorded(value, &seen))
                    .is_none()
            );
        }
        assert_eq!(queue.frontier.len(), 1);
        let groups = queue.pop_min_height_groups();
        assert!(groups.is_some(), "event group was missing");
        let Some(groups) = groups else {
            return;
        };
        assert_eq!(groups.len(), 1);
        run(groups);
        assert_eq!(snapshot(&seen), (0..16).collect::<Vec<_>>());
    }

    #[test]
    fn mixed_group_compacts_superseded_handles() {
        let id = Uuid::new_v4();
        let seen = Arc::new(Mutex::new(Vec::new()));
        let mut queue = ReadyQueue::new();
        assert!(queue.enqueue(id, 5, false, recorded(1, &seen)).is_none());
        for value in 2..=200 {
            let displaced = queue.enqueue(id, 5, true, recorded(value, &seen));
            drop(displaced);
        }
        let group = queue.frontier.get(&(5, id));
        assert!(group.is_some(), "mixed group was missing");
        let Some(group) = group else {
            return;
        };
        assert_eq!(group.live, 2);
        assert!(group.handle_count() <= 12);

        let groups = queue.pop_min_height_groups();
        assert!(groups.is_some(), "mixed group did not drain");
        let Some(groups) = groups else {
            return;
        };
        run(groups);
        assert_eq!(snapshot(&seen), vec![1, 200]);
    }

    #[test]
    fn matches_original_queue_for_mixed_deterministic_trace() {
        let ids = [Uuid::from_u128(1), Uuid::from_u128(2), Uuid::from_u128(3)];
        let seen = Arc::new(Mutex::new(Vec::new()));
        let mut queue = ReadyQueue::new();
        let mut reference = ReferenceQueue::new();

        for step in 0u16..300 {
            let id_index = usize::from(step.checked_rem(3).unwrap_or(0));
            let id = ids.get(id_index);
            assert!(id.is_some(), "generated invalid id index");
            let Some(&id) = id else {
                return;
            };
            let height = u64::from(step.checked_rem(5).unwrap_or(0));
            let coalesce = step.checked_rem(4).unwrap_or(0) != 0;
            let displaced = queue.enqueue(id, height, coalesce, recorded_u16(step, &seen));
            drop(displaced);
            reference.enqueue(id, height, coalesce, step);

            if step.checked_rem(17).unwrap_or(1) == 0 {
                let expected = reference.pop();
                let actual = queue.pop_min_height_groups();
                match (expected, actual) {
                    (Some(expected), Some(actual)) => {
                        run(actual);
                        assert_eq!(drain_u16(&seen), expected);
                    }
                    (None, None) => {}
                    (expected, actual) => {
                        assert_eq!(expected.is_some(), actual.is_some());
                        return;
                    }
                }
            }
        }

        loop {
            match (reference.pop(), queue.pop_min_height_groups()) {
                (Some(expected), Some(actual)) => {
                    run(actual);
                    assert_eq!(drain_u16(&seen), expected);
                }
                (None, None) => break,
                (expected, actual) => {
                    assert_eq!(expected.is_some(), actual.is_some());
                    break;
                }
            }
        }
    }
}
